Thank you for everyone on Reddit who was supportive for this little project! Everyone's support motivated me to spend all my free time getting a releasble version done ASAP.

This is Version 0.0.1 I would love any and all feedback on bugs and what you would like added.
As of right now my first goal is to add the HEX color code input, I hope to get that done in two weeks.
I will be releasing the Source code on Github soon that way people can contribute I just need to comment my code and document it that way I'm not tourturing people.


Using Modding Tools:

Nation Color/Culture
	Nation name will be the name of the txt file that teh Clausewitz Engine will read, spaces can't be used in naming, however dashes-can.
	You must generate text before exporting it, and if you do not chnage the name of a country in the input it will delete the old contents and put in the new code.
	

Localization
	TAG must be 3 letters and then add the naming localization for your nations.
	You must generate localization before exporting it.
	If you delete/move/do not have the localization file "countries_mod_l_english.yml" go into the Debug Stuff tab and click the "Create localization file" button.
	

 
Website: http://actadiurnadespqr.com/admodding.html
Discord for bug reporting or chatting: https://discord.gg/hshzSXkBxM